Here you will find all the MaxMSP patches and Code used for this Project





Warning!!!

Patches were made on Windows, so a few differences or errors may be presented on MacOS
